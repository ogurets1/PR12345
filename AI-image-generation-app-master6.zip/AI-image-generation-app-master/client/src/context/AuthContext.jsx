import React, { createContext, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  const register = async (formData) => {
    try {
      const response = await axios.post('http://localhost:8080/api/v1/auth/register', formData);
      console.log('Ответ на регистрацию:', response.data);
      navigate('/login');
    } catch (error) {
      console.error('Ошибка регистрации:', error.response ? error.response.data : error.message);
      if (error.response && error.response.data.message === 'Email уже используется') {
        alert('Email уже используется. Пожалуйста, попробуйте другой email.');
      } else {
        alert('Ошибка при регистрации пользователя. Пожалуйста, попробуйте позже.');
      }
    }
  };

  const login = async (formData) => {
    try {
      const { data } = await axios.post('http://localhost:8080/api/v1/auth/login', formData);
      localStorage.setItem('token', data.token);
      setUser({ id: data.userId });
      navigate('/');
    } catch (error) {
      console.error('Ошибка входа:', error);
      alert('Ошибка входа. Пожалуйста, попробуйте позже.');
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
    navigate('/login');
  };

  return (
    <AuthContext.Provider value={{ user, register, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
