
export { default as Home } from './Home';
export { default as CreatePost } from './CreatePost';
export { default as Login } from './Login';
export { default as Profile } from './Profile';
export { default as Register } from './Register';