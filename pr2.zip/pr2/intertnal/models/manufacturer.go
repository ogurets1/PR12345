package models

import "gorm.io/gorm"

type Manufacturer struct {
    gorm.Model
    Code    string `gorm:"unique"`
    Name    string
    Address string
    Phone   string
    Products []Product
}