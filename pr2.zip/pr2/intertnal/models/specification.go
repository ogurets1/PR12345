package models

import "gorm.io/gorm"

type Specification struct {
    gorm.Model
    ProductID     uint
    MaterialID    uint
    Quantity      float64
    DateEstablished string
    DateCancelled string
    Product       Product
    Material      Material
}