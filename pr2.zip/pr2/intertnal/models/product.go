package models

import "gorm.io/gorm"

type Product struct {
    gorm.Model
    ProductCode    string `gorm:"unique"`
    Name           string
    IsTypical      bool
    Purpose        string
    AnnualVolume   int
    ManufacturerID uint
    Manufacturer   Manufacturer
    Specifications []Specification
}