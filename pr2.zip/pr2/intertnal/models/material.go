package models

import "gorm.io/gorm"

type Material struct {
    gorm.Model
    Name          string
    Type          string
    Unit          string
    Price         float64
    UsedInProduct bool
    Specifications []Specification
}