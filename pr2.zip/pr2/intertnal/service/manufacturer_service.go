package service

import (
	"ogurets/intertnal/models"

	"gorm.io/gorm"
)

type ManufacturerService struct {
    db *gorm.DB
}

func NewManufacturerService(db *gorm.DB) *ManufacturerService {
    return &ManufacturerService{db: db}
}

func (ms *ManufacturerService) GetAllManufacturers() ([]models.Manufacturer, error) {
    var manufacturers []models.Manufacturer
    if err := ms.db.Find(&manufacturers).Error; err != nil {
        return nil, err
    }
    return manufacturers, nil
}