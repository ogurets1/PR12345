package service

import (
	"ogurets/intertnal/models"
    "gorm.io/gorm"
)

type ProductService struct {
    db *gorm.DB
}

func NewProductService(db *gorm.DB) *ProductService {
    return &ProductService{db: db}
}

func (ps *ProductService) GetAllProducts() ([]models.Product, error) {
    var products []models.Product
    if err := ps.db.Preload("Manufacturer").Find(&products).Error; err != nil {
        return nil, err
    }
    return products, nil
}

func (ps *ProductService) GetProductWithMostColorMetalMaterials() (*models.Product, error) {
    var product models.Product
    if err := ps.db.Raw(`
        SELECT p.*
        FROM products p
        JOIN specifications s ON p.id = s.product_id
        JOIN materials m ON s.material_id = m.id
        WHERE m.type = 'цветной металл'
        GROUP BY p.id
        ORDER BY COUNT(s.material_id) DESC
        LIMIT 1
    `).Scan(&product).Error; err != nil {
        return nil, err
    }
    return &product, nil
}

func (ps *ProductService) GetProductsNotProducedIn2023() ([]models.Product, error) {
    var products []models.Product
    if err := ps.db.Raw(`
        SELECT p.*
        FROM products p
        LEFT JOIN production pr ON p.id = pr.product_id AND pr.year = 2023
        WHERE pr.id IS NULL
    `).Scan(&products).Error; err != nil {
        return nil, err
    }
    return products, nil
}

func (ps *ProductService) GetProductsWithLowerMaterialCostsIn2024() ([]models.Product, error) {
    var products []models.Product
    if err := ps.db.Raw(`
        SELECT p.*
        FROM products p
        JOIN (
            SELECT product_id, SUM(quantity * price) as total_cost_2023
            FROM specifications s
            JOIN materials m ON s.material_id = m.id
            JOIN production pr ON s.product_id = pr.product_id
            WHERE pr.year = 2023
            GROUP BY product_id
        ) t2023 ON p.id = t2023.product_id
        JOIN (
            SELECT product_id, SUM(quantity * price) as total_cost_2024
            FROM specifications s
            JOIN materials m ON s.material_id = m.id
            JOIN production pr ON s.product_id = pr.product_id
            WHERE pr.year = 2024
            GROUP BY product_id
        ) t2024 ON p.id = t2024.product_id
        WHERE t2024.total_cost_2024 < t2023.total_cost_2023
    `).Scan(&products).Error; err != nil {
        return nil, err
    }
    return products, nil
}