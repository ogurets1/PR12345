package service

import (
	"ogurets/intertnal/models"

	"gorm.io/gorm"
)

type MaterialService struct {
    db *gorm.DB
}

func NewMaterialService(db *gorm.DB) *MaterialService {
    return &MaterialService{db: db}
}

func (ms *MaterialService) GetAllMaterials() ([]models.Material, error) {
    var materials []models.Material
    if err := ms.db.Find(&materials).Error; err != nil {
        return nil, err
    }
    return materials, nil
}

func (ms *MaterialService) GetAvgMonthlyUsageOfLapshaIn2023() (float64, error) {
    var avgUsage float64
    if err := ms.db.Raw(`
        SELECT AVG(quantity) as avg_monthly_usage
        FROM specifications s
        JOIN materials m ON s.material_id = m.id
        JOIN production pr ON s.product_id = pr.product_id
        WHERE m.name = 'лапша' AND pr.year = 2023
    `).Scan(&avgUsage).Error; err != nil {
        return 0, err
    }
    return avgUsage, nil
}