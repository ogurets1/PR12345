package service

import (
	"ogurets/intertnal/models"
    "gorm.io/gorm"
)

type SpecificationService struct {
    db *gorm.DB
}

func NewSpecificationService(db *gorm.DB) *SpecificationService {
    return &SpecificationService{db: db}
}

func (ss *SpecificationService) GetAllSpecifications() ([]models.Specification, error) {
    var specifications []models.Specification
    if err := ss.db.Preload("Product").Preload("Material").Find(&specifications).Error; err != nil {
        return nil, err
    }
    return specifications, nil
}