package routes

import (
    "github.com/gin-gonic/gin"
	"ogurets/intertnal/db"
	"ogurets/intertnal/handlers"
	"ogurets/intertnal/service"
)

func SetupRoutes(r *gin.Engine) {
    db := db.DB

    productService := service.NewProductService(db)
    manufacturerService := service.NewManufacturerService(db)
    materialService := service.NewMaterialService(db)
    specificationService := service.NewSpecificationService(db)

    productHandler := handlers.NewProductHandler(productService)
    manufacturerHandler := handlers.NewManufacturerHandler(manufacturerService)
    materialHandler := handlers.NewMaterialHandler(materialService)
    specificationHandler := handlers.NewSpecificationHandler(specificationService)

    r.LoadHTMLGlob("templates/*.html")

    r.GET("/", productHandler.IndexHandler)
    r.GET("/products", productHandler.ProductsHandler)
    r.GET("/manufacturers", manufacturerHandler.ManufacturersHandler)
    r.GET("/materials", materialHandler.MaterialsHandler)

    r.GET("/products/most-color-metal-materials", productHandler.ProductsWithMostColorMetalMaterialsHandler)
    r.GET("/products/not-produced-in-2023", productHandler.ProductsNotProducedIn2023Handler)
    r.GET("/products/lower-material-costs-in-2024", productHandler.ProductsWithLowerMaterialCostsIn2024Handler)
    r.GET("/materials/avg-monthly-usage-lapsha-2023", materialHandler.AvgMonthlyUsageOfLapshaIn2023Handler)
    r.GET("/specifications", specificationHandler.SpecificationsHandler)
}