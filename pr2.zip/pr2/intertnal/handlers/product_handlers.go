package handlers

import (
    "net/http"
	"ogurets/intertnal/service"
    "github.com/gin-gonic/gin"
)

type ProductHandler struct {
    productService *service.ProductService
}

func NewProductHandler(productService *service.ProductService) *ProductHandler {
    return &ProductHandler{productService: productService}
}

func (ph *ProductHandler) IndexHandler(c *gin.Context) {
    c.HTML(http.StatusOK, "index.html", gin.H{})
}

func (ph *ProductHandler) ProductsHandler(c *gin.Context) {
    products, err := ph.productService.GetAllProducts()
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    c.HTML(http.StatusOK, "products.html", gin.H{
        "products": products,
    })
}

func (ph *ProductHandler) ProductsWithMostColorMetalMaterialsHandler(c *gin.Context) {
    product, err := ph.productService.GetProductWithMostColorMetalMaterials()
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    c.JSON(http.StatusOK, product)
}

func (ph *ProductHandler) ProductsNotProducedIn2023Handler(c *gin.Context) {
    products, err := ph.productService.GetProductsNotProducedIn2023()
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    c.JSON(http.StatusOK, products)
}

func (ph *ProductHandler) ProductsWithLowerMaterialCostsIn2024Handler(c *gin.Context) {
    products, err := ph.productService.GetProductsWithLowerMaterialCostsIn2024()
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    c.JSON(http.StatusOK, products)
}