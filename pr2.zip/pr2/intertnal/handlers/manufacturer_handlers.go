package handlers

import (
	"net/http"
	"ogurets/intertnal/service"

	"github.com/gin-gonic/gin"
)

type ManufacturerHandler struct {
    manufacturerService *service.ManufacturerService
}

func NewManufacturerHandler(manufacturerService *service.ManufacturerService) *ManufacturerHandler {
    return &ManufacturerHandler{manufacturerService: manufacturerService}
}

func (mh *ManufacturerHandler) ManufacturersHandler(c *gin.Context) {
    manufacturers, err := mh.manufacturerService.GetAllManufacturers()
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    c.HTML(http.StatusOK, "manufacturers.html", gin.H{
        "manufacturers": manufacturers,
    })
}