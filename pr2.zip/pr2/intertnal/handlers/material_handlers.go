package handlers

import (
	"net/http"
	"ogurets/intertnal/service"

	"github.com/gin-gonic/gin"
)

type MaterialHandler struct {
    materialService *service.MaterialService
}

func NewMaterialHandler(materialService *service.MaterialService) *MaterialHandler {
    return &MaterialHandler{materialService: materialService}
}

func (mh *MaterialHandler) MaterialsHandler(c *gin.Context) {
    materials, err := mh.materialService.GetAllMaterials()
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    c.HTML(http.StatusOK, "materials.html", gin.H{
        "materials": materials,
    })
}

func (mh *MaterialHandler) AvgMonthlyUsageOfLapshaIn2023Handler(c *gin.Context) {
    avgUsage, err := mh.materialService.GetAvgMonthlyUsageOfLapshaIn2023()
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    c.JSON(http.StatusOK, gin.H{"avg_monthly_usage": avgUsage})
}