package handlers

import (
    "net/http"
	"ogurets/intertnal/service"
    "github.com/gin-gonic/gin"
)

type SpecificationHandler struct {
    specificationService *service.SpecificationService
}

func NewSpecificationHandler(specificationService *service.SpecificationService) *SpecificationHandler {
    return &SpecificationHandler{specificationService: specificationService}
}

func (sh *SpecificationHandler) SpecificationsHandler(c *gin.Context) {
    specifications, err := sh.specificationService.GetAllSpecifications()
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    c.JSON(http.StatusOK, specifications)
}