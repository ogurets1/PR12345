package db

import (
	"ogurets/intertnal/models"
    "gorm.io/gorm"
)

func SeedData(db *gorm.DB) {
    // Создание производителей
    manufacturers := []models.Manufacturer{
        {Code: "M001", Name: "Производитель 1", Address: "ул. Промышленная, д. 1", Phone: "+7 (123) 456-78-90"},
        {Code: "M002", Name: "Производитель 2", Address: "ул. Промышленная, д. 2", Phone: "+7 (123) 456-78-91"},
    }
    db.Create(&manufacturers)

    // Создание материалов
    materials := []models.Material{
        {Name: "цветной металл", Type: "металл", Unit: "кг", Price: 100.0, UsedInProduct: true},
        {Name: "лапша", Type: "продукт питания", Unit: "кг", Price: 50.0, UsedInProduct: true},
        {Name: "сталь", Type: "металл", Unit: "кг", Price: 80.0, UsedInProduct: true},
        {Name: "пластик", Type: "полимер", Unit: "кг", Price: 20.0, UsedInProduct: true},
    }
    db.Create(&materials)

    // Создание изделий
    products := []models.Product{
        {ProductCode: "P001", Name: "Продукт 1", IsTypical: true, Purpose: "Цель 1", AnnualVolume: 1000, ManufacturerID: 1},
        {ProductCode: "P002", Name: "Продукт 2", IsTypical: false, Purpose: "Цель 2", AnnualVolume: 1500, ManufacturerID: 2},
    }
    db.Create(&products)

    // Создание спецификаций
    specifications := []models.Specification{
        {ProductID: 1, MaterialID: 1, Quantity: 5.0, DateEstablished: "2023-01-01", DateCancelled: ""},
        {ProductID: 1, MaterialID: 2, Quantity: 10.0, DateEstablished: "2023-01-01", DateCancelled: ""},
        {ProductID: 2, MaterialID: 1, Quantity: 3.0, DateEstablished: "2023-01-01", DateCancelled: ""},
        {ProductID: 2, MaterialID: 3, Quantity: 7.0, DateEstablished: "2023-01-01", DateCancelled: ""},
    }
    db.Create(&specifications)

    // // Создание данных о производстве
    // productions := []models.Production{
    //     {ProductID: 1, Year: 2023, Volume: 800},
    //     {ProductID: 1, Year: 2024, Volume: 900},
    //     {ProductID: 2, Year: 2023, Volume: 1200},
    //     {ProductID: 2, Year: 2024, Volume: 1400},
    // }
    // db.Create(&productions)
}