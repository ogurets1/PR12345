package db

import (
    "fmt"
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"

	"ogurets/intertnal/models"
)

var DB *gorm.DB

func Init() {
    var err error
    DB, err = gorm.Open(sqlite.Open("test.db"), &gorm.Config{})
    if err != nil {
        fmt.Println("Failed to connect to database")
        panic("connection failed to database")
    }
    fmt.Println("Connection opened to database")

    DB.AutoMigrate(&models.Product{}, &models.Manufacturer{}, &models.Material{}, &models.Specification{})

    SeedData(DB)
}