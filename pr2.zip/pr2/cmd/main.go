package main

import (
    "github.com/gin-gonic/gin"
	"ogurets/intertnal/db"
	"ogurets/intertnal/routes"
)

func main() {
    db.Init()

    r := gin.Default()
    r.Static("/static", "./static")

    routes.SetupRoutes(r)

    r.Run(":8080")
}